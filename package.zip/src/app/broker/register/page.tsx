"use client";

import { FormEvent, useState } from "react";
import { supabase } from "@/lib/supabase";

export default function BrokerRegisterPage() {
  const [name, setName] = useState("");
  const [mobile, setMobile] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  async function handleRegister(e: FormEvent) {
    e.preventDefault();

    setLoading(true);
    setMessage("");
    setErrorMessage("");

    if (password.length < 6) {
      setErrorMessage("Password must be at least 6 characters.");
      setLoading(false);
      return;
    }

    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: {
        data: {
          full_name: name.trim(),
          mobile: mobile.trim(),
          role: "broker",
        },
      },
    });

    if (error) {
      console.error(error);
      setErrorMessage(error.message);
      setLoading(false);
      return;
    }

    if (data.session) {
      window.location.href = "/broker";
      return;
    }

    setMessage(
      "Registration successful. Please check your email to verify your account, then login."
    );

    setLoading(false);
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-[#f4f8fb] px-5 py-10">
      <div className="w-full max-w-md">

        <div className="mb-8 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-[#10b7d3] text-2xl font-black text-white">
            LK
          </div>

          <h1 className="mt-5 text-3xl font-black text-[#073b4c]">
            LoanKarts
          </h1>

          <p className="mt-1 text-sm font-semibold tracking-wide text-slate-500">
            BROKER PARTNER PORTAL
          </p>
        </div>

        <form
          onSubmit={handleRegister}
          className="rounded-3xl bg-white p-7 shadow-xl ring-1 ring-slate-200"
        >
          <h2 className="text-2xl font-black text-[#073b4c]">
            Become a Broker Partner
          </h2>

          <p className="mt-1 text-sm text-slate-500">
            Create your LoanKarts broker account.
          </p>

          {errorMessage && (
            <div className="mt-5 rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
              <p className="font-bold">❌ Registration failed</p>
              <p className="mt-1">{errorMessage}</p>
            </div>
          )}

          {message && (
            <div className="mt-5 rounded-xl border border-green-200 bg-green-50 p-4 text-sm text-green-700">
              <p className="font-bold">✅ Success</p>
              <p className="mt-1">{message}</p>
            </div>
          )}

          <div className="mt-6">
            <label className="mb-2 block text-sm font-bold text-slate-700">
              Broker Name
            </label>

            <input
              required
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Enter your full name"
              className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-[#10b7d3] focus:ring-2 focus:ring-cyan-100"
            />
          </div>

          <div className="mt-5">
            <label className="mb-2 block text-sm font-bold text-slate-700">
              Mobile Number
            </label>

            <input
              required
              type="tel"
              value={mobile}
              onChange={(e) => setMobile(e.target.value)}
              placeholder="Enter mobile number"
              className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-[#10b7d3] focus:ring-2 focus:ring-cyan-100"
            />
          </div>

          <div className="mt-5">
            <label className="mb-2 block text-sm font-bold text-slate-700">
              Email
            </label>

            <input
              required
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="broker@example.com"
              className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-[#10b7d3] focus:ring-2 focus:ring-cyan-100"
            />
          </div>

          <div className="mt-5">
            <label className="mb-2 block text-sm font-bold text-slate-700">
              Password
            </label>

            <input
              required
              type="password"
              minLength={6}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Minimum 6 characters"
              className="w-full rounded-xl border border-slate-300 px-4 py-3 outline-none focus:border-[#10b7d3] focus:ring-2 focus:ring-cyan-100"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="mt-6 w-full rounded-xl bg-[#073b4c] px-5 py-4 font-black text-white transition hover:bg-[#0b5269] disabled:cursor-not-allowed disabled:opacity-60"
          >
            {loading ? "Creating Account..." : "CREATE BROKER ACCOUNT →"}
          </button>

          <a
            href="/broker/login"
            className="mt-5 block text-center text-sm font-bold text-[#0b91a9] hover:underline"
          >
            Already have an account? Login
          </a>

          <a
            href="/"
            className="mt-3 block text-center text-sm font-bold text-slate-500 hover:underline"
          >
            ← Back to Main Website
          </a>
        </form>
      </div>
    </main>
  );
}