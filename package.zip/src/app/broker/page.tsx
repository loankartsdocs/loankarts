"use client";

import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/lib/supabase";

type FileStatus =
  | "Submitted"
  | "Processing"
  | "Approved"
  | "Disbursed"
  | "Rejected";

type DatabaseFile = {
  id: string;
  customer_name: string;
  mobile: string;
  loan_type: string;
  loan_amount: number;
  city: string;
  status: FileStatus;
  update_text: string | null;
  created_at: string;
};

type LoanFile = {
  id: string;
  customerName: string;
  mobile: string;
  loanType: string;
  loanAmount: number;
  city: string;
  status: FileStatus;
  update: string;
  date: string;
  commissionRate: number;
  commissionAmount: number;
};

function getCommissionRate(loanType: string) {
  const type = loanType.toLowerCase();

  if (type.includes("personal")) return 1.6;
  if (type.includes("business")) return 1.2;
  if (type.includes("home")) return 0.45;
  if (type.includes("lap")) return 0.6;
  if (type.includes("used") && type.includes("car")) return 1.5;
  if (type.includes("new") && type.includes("car")) return 0.5;

  return 0;
}

function formatMoney(value: number) {
  return `₹${Number(value || 0).toLocaleString("en-IN", {
    maximumFractionDigits: 2,
  })}`;
}

export default function BrokerDashboard() {
  const [files, setFiles] = useState<LoanFile[]>([]);
  const [loading, setLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  async function loadFiles() {
    setLoading(true);
    setErrorMessage("");

    try {
      const {
        data: { user },
        error: userError,
      } = await supabase.auth.getUser();

      if (userError) throw new Error(userError.message);

      if (!user) {
        window.location.href = "/broker/login";
        return;
      }

      const { data, error } = await supabase
        .from("loan_files")
        .select(
          "id, customer_name, mobile, loan_type, loan_amount, city, status, update_text, created_at"
        )
        .eq("broker_id", user.id)
        .order("created_at", { ascending: false });

      if (error) throw new Error(error.message);

      const formattedFiles: LoanFile[] = ((data || []) as DatabaseFile[]).map(
        (file) => {
          const amount = Number(file.loan_amount || 0);
          const rate = getCommissionRate(file.loan_type);
          const commission =
            file.status === "Disbursed" ? (amount * rate) / 100 : 0;

          return {
            id: file.id,
            customerName: file.customer_name,
            mobile: file.mobile,
            loanType: file.loan_type,
            loanAmount: amount,
            city: file.city,
            status: file.status,
            update: file.update_text || "No update available yet.",
            date: new Date(file.created_at).toLocaleDateString("en-IN", {
              day: "2-digit",
              month: "short",
              year: "numeric",
            }),
            commissionRate: rate,
            commissionAmount: commission,
          };
        }
      );

      setFiles(formattedFiles);
    } catch (error) {
      console.error(error);
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Unable to load your loan files."
      );
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadFiles();

    const channel = supabase
      .channel("broker-loan-files")
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "loan_files",
        },
        () => {
          loadFiles();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const stats = useMemo(() => {
    const totalCommission = files.reduce(
      (sum, file) => sum + file.commissionAmount,
      0
    );

    return {
      total: files.length,
      submitted: files.filter((f) => f.status === "Submitted").length,
      processing: files.filter((f) => f.status === "Processing").length,
      approved: files.filter((f) => f.status === "Approved").length,
      disbursed: files.filter((f) => f.status === "Disbursed").length,
      rejected: files.filter((f) => f.status === "Rejected").length,
      totalCommission,
    };
  }, [files]);

  function statusClass(status: FileStatus) {
    switch (status) {
      case "Disbursed":
        return "bg-green-100 text-green-700";
      case "Approved":
        return "bg-blue-100 text-blue-700";
      case "Processing":
        return "bg-amber-100 text-amber-700";
      case "Rejected":
        return "bg-red-100 text-red-700";
      default:
        return "bg-slate-100 text-slate-700";
    }
  }

  async function handleLogout() {
    await supabase.auth.signOut();
    window.location.href = "/broker/login";
  }

  return (
    <main className="min-h-screen bg-[#f4f8fb]">
      <header className="bg-[#073b4c] text-white shadow">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#10b7d3] font-black">
              LK
            </div>

            <div>
              <h1 className="text-xl font-black">LoanKarts</h1>
              <p className="text-xs tracking-wide text-slate-300">
                BROKER PARTNER PORTAL
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <a
              href="/"
              className="hidden rounded-xl border border-white/30 px-5 py-3 text-sm font-bold hover:bg-white hover:text-[#073b4c] md:block"
            >
              Main Website
            </a>

            <button
              onClick={handleLogout}
              className="rounded-xl border border-white/30 px-5 py-3 text-sm font-bold hover:bg-white hover:text-[#073b4c]"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-7xl px-4 py-8 sm:px-6 sm:py-10">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <p className="font-bold uppercase tracking-wide text-[#10b7d3]">
              Welcome, Broker Partner
            </p>

            <h2 className="mt-2 text-3xl font-black text-[#073b4c] sm:text-4xl">
              Broker Dashboard
            </h2>

            <p className="mt-2 text-slate-600">
              Track your submitted loan files and their latest updates.
            </p>
          </div>

          <a
            href="/broker/submit"
            className="rounded-xl bg-[#10b7d3] px-6 py-4 text-center font-black text-white shadow-lg transition hover:bg-[#0da8c1]"
          >
            + SUBMIT NEW FILE
          </a>
        </div>

        {errorMessage && (
          <div className="mt-6 rounded-2xl border border-red-200 bg-red-50 p-5 text-red-700">
            <p className="font-bold">❌ Unable to load files</p>
            <p className="mt-1 text-sm">{errorMessage}</p>

            <button
              onClick={loadFiles}
              className="mt-4 rounded-xl bg-red-600 px-5 py-2.5 text-sm font-bold text-white"
            >
              Try Again
            </button>
          </div>
        )}

        {/* STATS */}
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4 lg:grid-cols-7">
          <Stat title="Total Files" value={String(stats.total)} icon="📁" />
          <Stat title="Submitted" value={String(stats.submitted)} icon="📨" />
          <Stat title="Processing" value={String(stats.processing)} icon="⏳" />
          <Stat title="Approved" value={String(stats.approved)} icon="✅" />
          <Stat title="Disbursed" value={String(stats.disbursed)} icon="💰" />
          <Stat title="Rejected" value={String(stats.rejected)} icon="❌" />
          <Stat
            title="Commission"
            value={formatMoney(stats.totalCommission)}
            icon="💰"
          />
        </div>

        {/* FILES */}
        <div className="mt-8 overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
          <div className="flex flex-col justify-between gap-3 border-b border-slate-200 px-5 py-5 sm:px-6 md:flex-row md:items-center">
            <div>
              <h3 className="text-xl font-black text-[#073b4c]">
                My Loan Files
              </h3>
              <p className="mt-1 text-sm text-slate-500">
                Latest status and updates from LoanKarts.
              </p>
            </div>

            <a
              href="/broker/submit"
              className="rounded-xl border border-[#10b7d3] px-5 py-2.5 text-center text-sm font-bold text-[#0b91a9] hover:bg-cyan-50"
            >
              Submit Another File
            </a>
          </div>

          {loading ? (
            <div className="px-6 py-16 text-center">
              <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-slate-200 border-t-[#10b7d3]" />
              <p className="mt-4 text-sm font-semibold text-slate-500">
                Loading your loan files...
              </p>
            </div>
          ) : (
            <>
              {/* DESKTOP TABLE */}
              <div className="hidden overflow-x-auto lg:block">
                <table className="w-full">
                  <thead className="bg-slate-50">
                    <tr className="text-left text-xs uppercase tracking-wide text-slate-500">
                      <th className="px-5 py-4">File ID</th>
                      <th className="px-5 py-4">Customer</th>
                      <th className="px-5 py-4">Loan</th>
                      <th className="px-5 py-4">Status</th>
                      <th className="px-5 py-4">Commission</th>
                      <th className="px-5 py-4">Latest Update</th>
                      <th className="px-5 py-4">Date</th>
                    </tr>
                  </thead>

                  <tbody>
                    {files.map((file) => (
                      <tr
                        key={file.id}
                        className="border-t border-slate-100 hover:bg-slate-50"
                      >
                        <td className="px-5 py-5">
                          <span className="break-all font-black text-[#073b4c]">
                            {file.id}
                          </span>
                        </td>

                        <td className="px-5 py-5">
                          <p className="font-bold text-slate-800">
                            {file.customerName}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">
                            {file.mobile}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">
                            {file.city}
                          </p>
                        </td>

                        <td className="px-5 py-5">
                          <p className="font-semibold text-slate-700">
                            {file.loanType}
                          </p>
                          <p className="mt-1 text-xs text-slate-500">
                            {formatMoney(file.loanAmount)}
                          </p>
                        </td>

                        <td className="px-5 py-5">
                          <span
                            className={`rounded-full px-3 py-1.5 text-xs font-bold ${statusClass(
                              file.status
                            )}`}
                          >
                            {file.status}
                          </span>
                        </td>

                        <td className="px-5 py-5">
                          <p className="font-black text-green-600">
                            {formatMoney(file.commissionAmount)}
                          </p>
                          <p className="mt-1 text-xs text-slate-400">
                            {file.commissionRate}%
                            {file.status !== "Disbursed" && " • Disbursed only"}
                          </p>
                        </td>

                        <td className="max-w-xs px-5 py-5 text-sm text-slate-600">
                          {file.update}
                        </td>

                        <td className="px-5 py-5 text-sm text-slate-500">
                          {file.date}
                        </td>
                      </tr>
                    ))}

                    {files.length === 0 && (
                      <tr>
                        <td colSpan={7} className="px-6 py-14 text-center">
                          <div className="text-4xl">📁</div>
                          <p className="mt-3 font-bold text-slate-700">
                            No loan files submitted yet
                          </p>
                          <p className="mt-1 text-sm text-slate-500">
                            Submit your first loan file to start tracking it here.
                          </p>
                          <a
                            href="/broker/submit"
                            className="mt-5 inline-block rounded-xl bg-[#10b7d3] px-5 py-3 text-sm font-black text-white"
                          >
                            Submit New File
                          </a>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* MOBILE / TABLET CARDS */}
              <div className="grid gap-4 p-4 lg:hidden">
                {files.map((file) => (
                  <div
                    key={file.id}
                    className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
                          Customer
                        </p>
                        <p className="mt-1 text-lg font-black text-[#073b4c]">
                          {file.customerName}
                        </p>
                        <p className="text-sm text-slate-500">
                          {file.mobile} • {file.city}
                        </p>
                      </div>

                      <span
                        className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-bold ${statusClass(
                          file.status
                        )}`}
                      >
                        {file.status}
                      </span>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-3">
                      <InfoItem label="Loan Type" value={file.loanType} />
                      <InfoItem
                        label="Loan Amount"
                        value={formatMoney(file.loanAmount)}
                      />
                      <InfoItem
                        label="Commission Rate"
                        value={`${file.commissionRate}%`}
                      />
                      <InfoItem
                        label="Commission"
                        value={formatMoney(file.commissionAmount)}
                        green
                      />
                    </div>

                    <div className="mt-4 rounded-xl bg-slate-50 p-3">
                      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
                        Latest Update
                      </p>
                      <p className="mt-1 text-sm leading-6 text-slate-600">
                        {file.update}
                      </p>
                    </div>

                    <div className="mt-3 flex items-center justify-between text-xs text-slate-400">
                      <span>{file.date}</span>
                      <span className="max-w-[65%] truncate">{file.id}</span>
                    </div>
                  </div>
                ))}

                {files.length === 0 && (
                  <div className="px-4 py-14 text-center">
                    <div className="text-4xl">📁</div>
                    <p className="mt-3 font-bold text-slate-700">
                      No loan files submitted yet
                    </p>
                    <p className="mt-1 text-sm text-slate-500">
                      Submit your first loan file to start tracking it here.
                    </p>
                    <a
                      href="/broker/submit"
                      className="mt-5 inline-block rounded-xl bg-[#10b7d3] px-5 py-3 text-sm font-black text-white"
                    >
                      Submit New File
                    </a>
                  </div>
                )}
              </div>
            </>
          )}
        </div>

        <div className="mt-6 rounded-2xl border border-cyan-100 bg-cyan-50 p-5">
          <p className="font-bold text-[#073b4c]">📌 Live File Tracking</p>
          <p className="mt-1 text-sm leading-6 text-slate-600">
            When the LoanKarts team changes your application status or adds an
            update, it will appear here automatically.
          </p>
        </div>
      </section>
    </main>
  );
}

function Stat({
  title,
  value,
  icon,
}: {
  title: string;
  value: string;
  icon: string;
}) {
  return (
    <div className="min-w-0 rounded-2xl bg-white p-4 shadow-sm ring-1 ring-slate-200 sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <span className="text-xl sm:text-2xl">{icon}</span>

        <span className="truncate text-lg font-black text-[#073b4c] sm:text-2xl">
          {value}
        </span>
      </div>

      <p className="mt-3 truncate text-xs font-bold text-slate-500 sm:mt-4 sm:text-sm">
        {title}
      </p>
    </div>
  );
}

function InfoItem({
  label,
  value,
  green = false,
}: {
  label: string;
  value: string;
  green?: boolean;
}) {
  return (
    <div className="rounded-xl bg-slate-50 p-3">
      <p className="text-xs font-bold uppercase tracking-wide text-slate-400">
        {label}
      </p>
      <p
        className={`mt-1 text-sm font-black ${
          green ? "text-green-600" : "text-[#073b4c]"
        }`}
      >
        {value}
      </p>
    </div>
  );
}