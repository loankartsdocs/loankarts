"use client";

import { useState } from "react";

type FileStatus =
  | "Disbursed"
  | "Processing"
  | "Rejected"
  | "Submitted"
  | "Documents Pending"
  | "Approved";

type LoanFile = {
  id: string;
  customer: string;
  mobile: string;
  loanType: string;
  amount: string;
  bank: string;
  status: FileStatus;
  update: string;
  date: string;
  stage: string;
  remarks: string;
  documents: {
    name: string;
    status: "Uploaded" | "Pending";
  }[];
};

const loanTypes = [
  {
    title: "Personal Loan",
    icon: "👤",
    text: "Quick personal finance solutions.",
  },
  {
    title: "Business Loan",
    icon: "🏢",
    text: "Funding solutions for business growth.",
  },
  {
    title: "Home Loan",
    icon: "🏠",
    text: "Home finance solutions.",
  },
  {
    title: "Loan Against Property",
    icon: "🏦",
    text: "Unlock property value for funding.",
  },
  {
    title: "Car Loan",
    icon: "🚗",
    text: "Finance new or pre-owned vehicles.",
  },
  {
    title: "Education Loan",
    icon: "🎓",
    text: "Financial support for higher education.",
  },
];

const banks = [
  "SBI",
  "HDFC Bank",
  "ICICI Bank",
  "Axis Bank",
  "Kotak Mahindra",
  "IDFC FIRST Bank",
  "PNB",
  "Bajaj Finance",
  "IndusInd Bank",
  "Yes Bank",
  "RBL Bank",
  "Federal Bank",
];

const demoFiles: LoanFile[] = [
  {
    id: "LK-1001",
    customer: "Rahul Sharma",
    mobile: "98XXXXXX21",
    loanType: "Personal Loan",
    amount: "₹8,00,000",
    bank: "HDFC Bank",
    status: "Disbursed",
    update: "Loan disbursed successfully",
    date: "10 Aug 2026",
    stage: "Disbursement Completed",
    remarks: "Congratulations. Loan amount has been disbursed.",
    documents: [
      { name: "PAN Card", status: "Uploaded" },
      { name: "Aadhaar Card", status: "Uploaded" },
      { name: "Bank Statement", status: "Uploaded" },
      { name: "Salary Slip", status: "Uploaded" },
    ],
  },
  {
    id: "LK-1002",
    customer: "Amit Kumar",
    mobile: "99XXXXXX45",
    loanType: "Business Loan",
    amount: "₹15,00,000",
    bank: "ICICI Bank",
    status: "Processing",
    update: "Bank verification in progress",
    date: "10 Aug 2026",
    stage: "Bank Verification",
    remarks: "Bank is verifying the applicant's banking details.",
    documents: [
      { name: "PAN Card", status: "Uploaded" },
      { name: "Aadhaar Card", status: "Uploaded" },
      { name: "GST Documents", status: "Uploaded" },
      { name: "ITR", status: "Pending" },
    ],
  },
  {
    id: "LK-1003",
    customer: "Neha Singh",
    mobile: "97XXXXXX18",
    loanType: "Home Loan",
    amount: "₹35,00,000",
    bank: "SBI",
    status: "Processing",
    update: "Income documents under review",
    date: "09 Aug 2026",
    stage: "Credit Assessment",
    remarks: "Income documents are currently under lender review.",
    documents: [
      { name: "PAN Card", status: "Uploaded" },
      { name: "Aadhaar Card", status: "Uploaded" },
      { name: "Salary Slip", status: "Uploaded" },
      { name: "Property Documents", status: "Pending" },
    ],
  },
  {
    id: "LK-1004",
    customer: "Vikas Verma",
    mobile: "96XXXXXX54",
    loanType: "Personal Loan",
    amount: "₹5,00,000",
    bank: "Axis Bank",
    status: "Rejected",
    update: "Eligibility criteria not met",
    date: "08 Aug 2026",
    stage: "Application Closed",
    remarks: "Application could not proceed based on lender eligibility criteria.",
    documents: [
      { name: "PAN Card", status: "Uploaded" },
      { name: "Aadhaar Card", status: "Uploaded" },
      { name: "Salary Slip", status: "Uploaded" },
    ],
  },
  {
    id: "LK-1005",
    customer: "Pooja Gupta",
    mobile: "95XXXXXX72",
    loanType: "Business Loan",
    amount: "₹10,00,000",
    bank: "Bajaj Finance",
    status: "Submitted",
    update: "File submitted to LoanKarts team",
    date: "08 Aug 2026",
    stage: "Initial Review",
    remarks: "LoanKarts team will review the submitted file.",
    documents: [
      { name: "PAN Card", status: "Uploaded" },
      { name: "Aadhaar Card", status: "Uploaded" },
      { name: "Bank Statement", status: "Pending" },
      { name: "GST Documents", status: "Pending" },
    ],
  },
];

export default function Home() {
  const [mobileMenu, setMobileMenu] = useState(false);

  return (
    <main className="min-h-screen bg-white text-slate-900">

      {/* TOP BAR */}
      <div className="bg-[#08283a] text-white text-sm">
        <div className="mx-auto max-w-7xl px-6 py-2 flex flex-col sm:flex-row justify-between gap-2">
          <span>LoanKarts — Your trusted loan assistance partner</span>
          <span>Call: +91 99909 54351</span>
        </div>
      </div>

      {/* NAVBAR */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur border-b border-slate-200">
        <div className="mx-auto max-w-7xl px-6 h-20 flex items-center justify-between">

          <a href="#" className="flex items-center gap-3">
            <div className="h-12 w-12 rounded-xl bg-[#0a4963] flex items-center justify-center text-white font-black text-xl">
              LK
            </div>

            <div>
              <div className="text-2xl font-black text-[#0a3448]">
                Loan<span className="text-[#08b8d4]">Karts</span>
              </div>

              <div className="text-[9px] tracking-widest text-slate-500">
                YOU THINK TO GROW, WE CAN HELP
              </div>
            </div>
          </a>

          <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold">

            <a href="#home" className="hover:text-[#08aeca]">
              Home
            </a>

            <a href="#loans" className="hover:text-[#08aeca]">
              Loans
            </a>

            <a href="#calculator" className="hover:text-[#08aeca]">
              EMI Calculator
            </a>

            <a href="#about" className="hover:text-[#08aeca]">
              About
            </a>

            <a href="#contact" className="hover:text-[#08aeca]">
              Contact
            </a>

            <button
              onClick={() => { window.location.href = "/broker/login"; }}
              className="rounded-full border-2 border-[#0a4963] px-5 py-2.5 text-[#0a4963] hover:bg-[#0a4963] hover:text-white transition"
            >
              🔐 Broker Login
            </button>

            <a
              href="#apply"
              className="rounded-full bg-[#08b8d4] px-6 py-3 text-white shadow-lg hover:bg-[#079db6]"
            >
              Apply Now
            </a>
          </nav>

          <button
            className="lg:hidden text-2xl"
            onClick={() => setMobileMenu(!mobileMenu)}
          >
            ☰
          </button>
        </div>

        {mobileMenu && (
          <div className="lg:hidden border-t bg-white px-6 py-5 space-y-4">

            <a href="#home" className="block">
              Home
            </a>

            <a href="#loans" className="block">
              Loans
            </a>

            <a href="#calculator" className="block">
              EMI Calculator
            </a>

            <a href="#about" className="block">
              About
            </a>

            <a href="#contact" className="block">
              Contact
            </a>

            <button
              onClick={() => { window.location.href = "/broker/login"; }}
              className="w-full rounded-xl border-2 border-[#0a4963] py-3 text-[#0a4963]"
            >
              🔐 Broker Login
            </button>

            <a
              href="#apply"
              className="block text-center rounded-xl bg-[#08b8d4] py-3 text-white"
            >
              Apply Now
            </a>

          </div>
        )}
      </header>

      {/* HERO */}
      <section
        id="home"
        className="relative overflow-hidden bg-[#174c64] text-white"
      >
        <div className="mx-auto max-w-7xl px-6 py-24 lg:py-32">

          <div className="max-w-3xl">

            <div className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm mb-7">
              <span className="h-2 w-2 rounded-full bg-[#19d4e8]" />
              Simple • Transparent • Customer Focused
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-black leading-tight">
              Finance your
              <span className="text-[#16c6dc]"> dreams</span>
              <br />
              with confidence.
            </h1>

            <p className="mt-7 max-w-2xl text-lg md:text-xl leading-8 text-white/80">
              LoanKarts helps you explore suitable loan options,
              prepare your documents and submit your application with
              professional assistance.
            </p>

            <div className="mt-9 flex flex-col sm:flex-row gap-4">

              <a
                href="#apply"
                className="rounded-xl bg-[#08b8d4] px-8 py-4 text-center font-bold shadow-xl"
              >
                APPLY NOW →
              </a>

              <a
                href="#calculator"
                className="rounded-xl border border-white/50 px-8 py-4 text-center font-bold hover:bg-white hover:text-[#174c64]"
              >
                CALCULATE EMI
              </a>

            </div>

            <div className="mt-10 flex flex-wrap gap-8 text-sm text-white/80">
              <span>✓ Multiple loan categories</span>
              <span>✓ Document assistance</span>
              <span>✓ Human support</span>
            </div>

          </div>
        </div>
      </section>

      {/* TRUST CARDS */}
      <section className="relative -mt-10 z-10 mx-auto max-w-6xl px-6">

        <div className="grid md:grid-cols-3 rounded-2xl bg-white shadow-2xl border border-slate-100 overflow-hidden">

          <TrustCard
            icon="🛡️"
            title="Trusted Loan Solutions"
            text="Transparent assistance and customer-focused loan support."
          />

          <TrustCard
            icon="👨‍💼"
            title="Expert Assistance"
            text="Professional help with documentation and applications."
            border
          />

          <TrustCard
            icon="⚡"
            title="Simple Process"
            text="Apply online and track your application with our team."
          />

        </div>
      </section>

      {/* LOAN CATEGORIES */}
      <section id="loans" className="py-24 bg-[#f5f8fb]">

        <div className="mx-auto max-w-7xl px-6">

          <div className="text-center max-w-3xl mx-auto">

            <div className="text-[#08aeca] font-bold tracking-widest text-sm">
              OUR LOAN SOLUTIONS
            </div>

            <h2 className="mt-3 text-4xl md:text-5xl font-black text-[#0a3448]">
              Find the right loan for your needs
            </h2>

            <p className="mt-5 text-lg text-slate-600">
              Explore different financing options and connect with our
              assistance team.
            </p>

          </div>

          <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">

            {loanTypes.map((loan) => (
              <div
                key={loan.title}
                className="group rounded-2xl bg-white border border-slate-200 p-7 shadow-sm hover:-translate-y-1 hover:shadow-xl transition"
              >

                <div className="h-14 w-14 rounded-xl bg-[#e8f8fb] flex items-center justify-center text-3xl">
                  {loan.icon}
                </div>

                <h3 className="mt-6 text-xl font-bold text-[#0a3448]">
                  {loan.title}
                </h3>

                <p className="mt-3 text-slate-600">
                  {loan.text}
                </p>

                <a
                  href="#apply"
                  className="mt-6 inline-block font-bold text-[#079eb7]"
                >
                  Apply Now →
                </a>

              </div>
            ))}

          </div>
        </div>
      </section>

      {/* EMI */}
      <section id="calculator" className="py-24 bg-white">
        <EMICalculator />
      </section>

      {/* PROCESS */}
      <section className="py-24 bg-[#082f42] text-white">

        <div className="mx-auto max-w-7xl px-6">

          <div className="text-center">

            <div className="text-[#16c6dc] font-bold tracking-widest">
              HOW IT WORKS
            </div>

            <h2 className="mt-3 text-4xl md:text-5xl font-black">
              Simple loan application process
            </h2>

          </div>

          <div className="mt-16 grid md:grid-cols-4 gap-8">

            {[
              ["01", "Choose Loan", "Select the loan product suitable for your requirement."],
              ["02", "Apply Online", "Fill your basic details through our application form."],
              ["03", "Submit Documents", "Upload the required documents securely."],
              ["04", "Get Updates", "Track your application with our team."],
            ].map(([number, title, text]) => (

              <div key={number}>

                <div className="text-5xl font-black text-[#16c6dc]/40">
                  {number}
                </div>

                <h3 className="mt-4 text-xl font-bold">
                  {title}
                </h3>

                <p className="mt-3 text-white/70 leading-7">
                  {text}
                </p>

              </div>

            ))}

          </div>
        </div>
      </section>

      {/* BANK NETWORK */}
      <section className="py-24 bg-[#f5f8fb]">

        <div className="mx-auto max-w-7xl px-6">

          <div className="text-center">

            <div className="text-[#08aeca] font-bold tracking-widest">
              OUR NETWORK
            </div>

            <h2 className="mt-3 text-4xl md:text-5xl font-black text-[#0a3448]">
              Banking & Financial Network
            </h2>

            <p className="mt-5 max-w-2xl mx-auto text-slate-600">
              We work with a network of banks and financial institutions
              depending on customer eligibility and loan requirements.
            </p>

          </div>

          <div className="mt-14 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">

            {banks.map((bank) => (
              <div
                key={bank}
                className="bg-white border border-slate-200 rounded-2xl px-5 py-7 text-center font-bold text-[#31516e] shadow-sm hover:shadow-md"
              >
                {bank}
              </div>
            ))}

          </div>

          <p className="mt-8 text-center text-xs text-slate-500">
            Loan eligibility, interest rates, fees and final approval are
            determined by the respective lender.
          </p>

        </div>
      </section>

      {/* ABOUT */}
      <section id="about" className="py-24 bg-white">

        <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-16 items-center">

          <div>

            <div className="text-[#08aeca] font-bold tracking-widest">
              WHY LOANKARTS
            </div>

            <h2 className="mt-4 text-4xl md:text-5xl font-black text-[#0a3448]">
              More than just a loan application.
            </h2>

            <p className="mt-6 text-lg text-slate-600 leading-8">
              We help customers understand the loan process, prepare
              documents and connect their requirements with suitable
              financial products.
            </p>

            <div className="mt-8 space-y-5">

              {[
                "Multiple loan categories",
                "Online application facility",
                "Document checklist & assistance",
                "Application status updates",
                "Professional support",
                "Transparent process",
              ].map((item) => (

                <div key={item} className="flex items-center gap-3">

                  <div className="h-7 w-7 rounded-full bg-[#e6f8fb] text-[#08aeca] flex items-center justify-center font-bold">
                    ✓
                  </div>

                  <span className="font-semibold">
                    {item}
                  </span>

                </div>

              ))}

            </div>
          </div>

          <div className="rounded-3xl bg-[#174c64] p-10 text-white shadow-2xl">

            <div className="text-6xl">💼</div>

            <h3 className="mt-7 text-3xl font-black">
              Want to work with LoanKarts?
            </h3>

            <p className="mt-5 text-white/75 leading-7">
              If you are a loan broker, DSA, agent or financial professional
              and want to work with us, register with LoanKarts and manage
              your files through our broker portal.
            </p>

            <button
              onClick={() => { window.location.href = "/broker/login"; }}
              className="mt-8 rounded-xl bg-[#08b8d4] px-7 py-4 font-bold"
            >
              🔐 BROKER LOGIN / JOIN US
            </button>

          </div>

        </div>
      </section>

      {/* APPLY */}
      <section id="apply" className="py-24 bg-[#f5f8fb]">

        <div className="mx-auto max-w-4xl px-6">

          <div className="text-center">

            <div className="text-[#08aeca] font-bold tracking-widest">
              GET STARTED
            </div>

            <h2 className="mt-3 text-4xl md:text-5xl font-black text-[#0a3448]">
              Apply for a loan
            </h2>

            <p className="mt-4 text-slate-600">
              Tell us about your requirement. Our team will contact you.
            </p>

          </div>

          <div className="mt-12 bg-white rounded-3xl shadow-xl border border-slate-200 p-8 md:p-10">

            <div className="grid md:grid-cols-2 gap-5">

              <input
                placeholder="Full Name"
                className="rounded-xl border border-slate-300 px-5 py-4 outline-none focus:border-[#08aeca]"
              />

              <input
                placeholder="Mobile Number"
                className="rounded-xl border border-slate-300 px-5 py-4 outline-none focus:border-[#08aeca]"
              />

              <select className="rounded-xl border border-slate-300 px-5 py-4 outline-none">
                <option>Select Loan Type</option>
                {loanTypes.map((loan) => (
                  <option key={loan.title}>{loan.title}</option>
                ))}
              </select>

              <input
                placeholder="Required Loan Amount"
                className="rounded-xl border border-slate-300 px-5 py-4 outline-none"
              />

            </div>

            <textarea
              placeholder="Tell us briefly about your requirement"
              rows={4}
              className="mt-5 w-full rounded-xl border border-slate-300 px-5 py-4 outline-none"
            />

            <button
              onClick={() =>
                alert("Application received. Backend connection will be added next.")
              }
              className="mt-6 w-full rounded-xl bg-[#08b8d4] py-4 text-white font-bold text-lg"
            >
              SUBMIT APPLICATION →
            </button>

          </div>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="py-20 bg-white">

        <div className="mx-auto max-w-7xl px-6">

          <div className="grid md:grid-cols-3 gap-6">

            <ContactCard
              icon="📞"
              title="Call Us"
              text="+91 99909 54351"
            />

            <ContactCard
              icon="✉️"
              title="Email"
              text="docs@loankarts.com"
            />

            <ContactCard
              icon="📍"
              title="Location"
              text="SGM Nagar, Faridabad, Haryana"
            />

          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#061d2b] text-white">

        <div className="mx-auto max-w-7xl px-6 py-16">

          <div className="grid md:grid-cols-4 gap-12">

            <div>

              <div className="text-3xl font-black">
                Loan<span className="text-[#08b8d4]">Karts</span>
              </div>

              <p className="mt-5 text-white/60 leading-7">
                Your trusted loan assistance partner for personal,
                business, home, vehicle and other financial needs.
              </p>

            </div>

            <div>

              <h3 className="font-bold text-lg">
                Loan Solutions
              </h3>

              <div className="mt-5 space-y-3 text-white/60">
                <p>Personal Loan</p>
                <p>Business Loan</p>
                <p>Home Loan</p>
                <p>Loan Against Property</p>
                <p>Car Loan</p>
              </div>

            </div>

            <div>

              <h3 className="font-bold text-lg">
                Company
              </h3>

              <div className="mt-5 space-y-3 text-white/60">
                <p>About Us</p>
                <p>Contact Us</p>
                <p>EMI Calculator</p>
                <p>Privacy Policy</p>
                <p>Terms & Conditions</p>
              </div>

            </div>

            <div>

              <h3 className="font-bold text-lg">
                For Partners
              </h3>

              <div className="mt-5 space-y-3 text-white/60">
                <p>Broker Login</p>
                <p>Partner With Us</p>
                <p>Submit A File</p>
                <p>Track Applications</p>
              </div>

              <button
                onClick={() => { window.location.href = "/broker/login"; }}
                className="mt-6 rounded-xl bg-[#08b8d4] px-5 py-3 font-bold"
              >
                Broker Portal →
              </button>

            </div>

          </div>

          <div className="mt-12 border-t border-white/10 pt-7 text-sm text-white/40">
            © 2026 LoanKarts. All rights reserved.
          </div>

        </div>
      </footer>

      {/* WHATSAPP */}
      <a
        href="https://wa.me/919990954351"
        target="_blank"
        rel="noreferrer"
        className="fixed bottom-6 right-6 z-50 h-16 w-16 rounded-full bg-[#25D366] flex items-center justify-center text-white text-3xl shadow-2xl"
      >
        ☎
      </a>

    </main>
  );
}


/* =====================================================
   TRUST CARD
===================================================== */

function TrustCard({
  icon,
  title,
  text,
  border = false,
}: {
  icon: string;
  title: string;
  text: string;
  border?: boolean;
}) {
  return (
    <div
      className={`p-8 ${
        border
          ? "border-y md:border-y-0 md:border-x border-slate-200"
          : ""
      }`}
    >

      <div className="text-3xl">
        {icon}
      </div>

      <h3 className="mt-4 text-xl font-bold text-[#0a3448]">
        {title}
      </h3>

      <p className="mt-2 text-slate-600">
        {text}
      </p>

    </div>
  );
}


/* =====================================================
   CONTACT CARD
===================================================== */

function ContactCard({
  icon,
  title,
  text,
}: {
  icon: string;
  title: string;
  text: string;
}) {
  return (
    <div className="rounded-2xl bg-[#f5f8fb] p-7">

      <div className="text-3xl">
        {icon}
      </div>

      <h3 className="mt-4 font-bold text-xl">
        {title}
      </h3>

      <p className="mt-2 text-slate-600">
        {text}
      </p>

    </div>
  );
}


/* =====================================================
   EMI CALCULATOR
===================================================== */

function EMICalculator() {

  const [amount, setAmount] = useState(500000);
  const [rate, setRate] = useState(12);
  const [years, setYears] = useState(5);

  const months = years * 12;
  const monthlyRate = rate / 12 / 100;

  const emi =
    monthlyRate === 0
      ? amount / months
      : (amount * monthlyRate * Math.pow(1 + monthlyRate, months)) /
        (Math.pow(1 + monthlyRate, months) - 1);

  const totalPayment = emi * months;
  const totalInterest = totalPayment - amount;

  const money = (value: number) =>
    new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(value);

  return (
    <div className="mx-auto max-w-6xl px-6">

      <div className="text-center">

        <div className="text-[#08aeca] font-bold tracking-widest">
          EMI CALCULATOR
        </div>

        <h2 className="mt-3 text-4xl md:text-5xl font-black text-[#0a3448]">
          Calculate your monthly EMI
        </h2>

      </div>

      <div className="mt-14 grid lg:grid-cols-2 gap-10">

        <div className="rounded-3xl bg-[#f5f8fb] p-8">

          <label className="font-bold">
            Loan Amount
          </label>

          <input
            type="range"
            min="50000"
            max="10000000"
            step="50000"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="mt-5 w-full"
          />

          <div className="mt-3 text-2xl font-black text-[#0a4963]">
            {money(amount)}
          </div>

          <label className="mt-8 block font-bold">
            Interest Rate
          </label>

          <input
            type="range"
            min="5"
            max="25"
            step="0.1"
            value={rate}
            onChange={(e) => setRate(Number(e.target.value))}
            className="mt-5 w-full"
          />

          <div className="mt-3 text-2xl font-black text-[#0a4963]">
            {rate}%
          </div>

          <label className="mt-8 block font-bold">
            Loan Tenure
          </label>

          <input
            type="range"
            min="1"
            max="30"
            step="1"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="mt-5 w-full"
          />

          <div className="mt-3 text-2xl font-black text-[#0a4963]">
            {years} Years
          </div>

        </div>

        <div className="rounded-3xl bg-[#174c64] text-white p-8">

          <div className="text-white/70">
            Estimated Monthly EMI
          </div>

          <div className="mt-3 text-5xl font-black text-[#16c6dc]">
            {money(emi)}
          </div>

          <div className="mt-10 grid grid-cols-2 gap-5">

            <div className="rounded-2xl bg-white/10 p-5">
              <div className="text-sm text-white/60">
                Principal
              </div>

              <div className="mt-2 text-xl font-bold">
                {money(amount)}
              </div>
            </div>

            <div className="rounded-2xl bg-white/10 p-5">
              <div className="text-sm text-white/60">
                Interest
              </div>

              <div className="mt-2 text-xl font-bold">
                {money(totalInterest)}
              </div>
            </div>

          </div>

          <div className="mt-5 rounded-2xl bg-white/10 p-5">

            <div className="text-sm text-white/60">
              Total Payment
            </div>

            <div className="mt-2 text-2xl font-bold">
              {money(totalPayment)}
            </div>

          </div>

          <a
            href="#apply"
            className="mt-8 block text-center rounded-xl bg-[#08b8d4] px-6 py-4 font-bold"
          >
            APPLY FOR LOAN →
          </a>

          <p className="mt-4 text-xs text-white/50">
            This calculator provides an estimate only.
          </p>

        </div>

      </div>
    </div>
  );
}